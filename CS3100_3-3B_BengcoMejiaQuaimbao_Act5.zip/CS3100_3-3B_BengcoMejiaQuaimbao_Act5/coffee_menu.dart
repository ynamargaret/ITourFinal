import 'package:flutter/material.dart';
import 'coffee_model.dart';
import 'coffee_item.dart';

class CoffeeMenu extends StatelessWidget {
  final void Function(String) onOrder;
  final List<String> favoriteNames;
  final void Function(String, bool) onFavoriteToggle;

  CoffeeMenu({
    super.key,
    required this.onOrder,
    required this.favoriteNames,
    required this.onFavoriteToggle,
  });

  final List<Coffee> coffeeList = [
    Coffee(
      imagePath: 'assets/img/5.png',
      name: 'Toffee Nut Latte',
      description:
          'Para sa chill at lowkey lang magmahal.\nIngredients: Toffee nut syrup, espresso, steamed milk\nToppings: Caramel crunch, light foam',
      price: '₱95',
    ),
    Coffee(
      imagePath: 'assets/img/6.png',
      name: 'Matcha',
      description:
          'Green tea latte para sa mga independent na di kailangan ng ka-date.\nIngredients: Matcha powder, oat milk, espresso shot (optional)\nToppings: Cream foam, crushed graham',
      price: '₱99',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: coffeeList.length,
      itemBuilder: (context, index) {
        final coffee = coffeeList[index];
        return CoffeeItem(
          imagePath: coffee.imagePath,
          name: coffee.name,
          description: coffee.description,
          price: coffee.price,
          onOrder: () => onOrder(coffee.name),
          isInitiallyFavorite: favoriteNames.contains(coffee.name),
          onFavoriteChanged: (isFav) => onFavoriteToggle(coffee.name, isFav),
        );
      },
    );
  }
}
