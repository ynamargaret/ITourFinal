import 'package:flutter/material.dart';
import 'coffee_model.dart';
import 'coffee_item.dart';

const List<Coffee> allCoffees = [
  Coffee(
    imagePath: 'assets/img/5.png',
    name: 'Toffee Nut Latte',
    description: 'Toffee nut syrup, espresso, steamed milk...',
    price: '₱95',
  ),
  Coffee(
    imagePath: 'assets/img/6.png',
    name: 'Matcha',
    description: 'Matcha, oat milk, graham...',
    price: '₱99',
  ),
];

class FavoritesScreen extends StatefulWidget {
  final List<String> favoriteNames;
  final void Function(String name, bool isFavorite) onFavoriteToggle;

  const FavoritesScreen({
    super.key,
    required this.favoriteNames,
    required this.onFavoriteToggle,
  });

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late List<String> favorites;

  @override
  void initState() {
    super.initState();
    favorites = List.from(widget.favoriteNames);
  }

  void handleFavoriteChanged(String coffeeName, bool isFav) {
    setState(() {
      if (!isFav) {
        favorites.remove(coffeeName);
      } else {
        favorites.add(coffeeName);
      }
    });
    widget.onFavoriteToggle(coffeeName, isFav);
  }

  @override
  Widget build(BuildContext context) {
    final favoriteCoffees =
        allCoffees.where((coffee) => favorites.contains(coffee.name)).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Favorites'),
        backgroundColor: Colors.brown,
      ),
      body: favoriteCoffees.isEmpty
          ? const Center(
              child: Text(
                'No favorites yet!',
                style: TextStyle(fontSize: 18, color: Colors.black54),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: favoriteCoffees.length,
              itemBuilder: (context, index) {
                final coffee = favoriteCoffees[index];
                return CoffeeItem(
                  imagePath: coffee.imagePath,
                  name: coffee.name,
                  description: coffee.description,
                  price: coffee.price,
                  onOrder: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Ordered ${coffee.name}')),
                    );
                  },
                  isInitiallyFavorite: true,
                  onFavoriteChanged: (isFav) =>
                      handleFavoriteChanged(coffee.name, isFav),
                );
              },
            ),
    );
  }
}
