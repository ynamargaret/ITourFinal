import 'package:flutter/material.dart';
import 'coffee_menu.dart';
import 'second_screen.dart';
import 'favorites_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int totalCoffeeOrders = 0;

  final List<String> favoriteNames = [];

  final Map<String, int> orderedItems = {};

  void incrementOrder(String itemName) {
    setState(() {
      totalCoffeeOrders++;
      orderedItems[itemName] = (orderedItems[itemName] ?? 0) + 1;
    });

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Order Confirmed'),
        content: Text('You ordered: $itemName'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void toggleFavorite(String name, bool isAdding) {
    setState(() {
      if (isAdding) {
        if (!favoriteNames.contains(name)) {
          favoriteNames.add(name);
        }
      } else {
        favoriteNames.remove(name);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Color.fromRGBO(121, 85, 72, 0)),
                child: Text(
                  'Menu',
                  style: TextStyle(color: Colors.brown, fontSize: 24),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: const Text('Home'),
                onTap: () => Navigator.of(context).pop(),
              ),
              ListTile(
                leading: const Icon(Icons.favorite),
                title: const Text('Favorites'),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => FavoritesScreen(
                        favoriteNames: favoriteNames,
                        onFavoriteToggle: toggleFavorite,
                      ),
                    ),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.shopping_cart),
                title: const Text('Order Summary'),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) =>
                          SecondScreen(orderedItems: orderedItems),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(160),
        child: Builder(
          builder: (context) {
            final double topPadding = MediaQuery.of(context).padding.top;
            return Container(
              padding: EdgeInsets.only(top: topPadding + 8, left: 8, right: 8),
              color: const Color(0xFFEFE5DC),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Center(
                    child: Image.asset(
                      'assets/img/logo.png',
                      height: 150,
                      fit: BoxFit.contain,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      icon: const Icon(Icons.menu),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
      body: CoffeeMenu(
        onOrder: incrementOrder,
        favoriteNames: favoriteNames,
        onFavoriteToggle: toggleFavorite,
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        color: const Color.fromRGBO(239, 229, 220, 1),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text(
              'Developed by A.Bengco | R.Mejia | Q.Allyna',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 6),
            Text(
              '© 2025 Android Studio',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
            SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.email, size: 16, color: Colors.brown),
                SizedBox(width: 6),
                Icon(Icons.facebook, size: 16, color: Colors.blue),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
