import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blueGrey,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Logout'),
            ),
          ],
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(160),
        child: Builder(
          builder: (context) {
            final double topPadding = MediaQuery.of(context).padding.top;

            return Container(
              padding: EdgeInsets.only(top: topPadding + 8, left: 8, right: 8),
              color: const Color(0xFFEFE5DC),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.menu),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                  Expanded(
                    child: Center(
                      child: Image.asset(
                        'assets/img/logo.png',
                        height: 150,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      print('Selected: $value');
                    },
                    itemBuilder: (BuildContext context) => [
                      const PopupMenuItem(
                        value: 'profile',
                        child: Text('Profile'),
                      ),
                      const PopupMenuItem(
                        value: 'settings',
                        child: Text('Settings'),
                      ),
                      const PopupMenuItem(
                        value: 'logout',
                        child: Text('Logout'),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
      body: const CoffeeMenu(),

bottomNavigationBar: Container(
  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
  color: const Color.fromRGBO(239, 229, 220, 1), // Light coffee color
  child: Column(
    mainAxisSize: MainAxisSize.min,
    children: const [
      Text(
        'Developed by A.Bengco | R.Mejia | Q.Allyna',
        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ),
      SizedBox(height: 6),
      Text(
        '© 2025 Android Studo',
        style: TextStyle(fontSize: 12, color: Colors.black54),
      ),
            SizedBox(height: 4),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.email, size: 16, color: Colors.brown),
          SizedBox(width: 6),
          Icon(Icons.facebook, size: 16, color: Colors.blue),
          SizedBox(width: 6),
        ],
      ),
    ],
  ),
),

    );
  }
}

class CoffeeMenu extends StatelessWidget {
  const CoffeeMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: const [
          CoffeeItem(
            imagePath: 'assets/img/5.png',
            name: 'Toffee Nut Latte',
            description: 'Para sa chill at lowkey lang magmahal.\nIngredients: Toffee nut syrup, \nespresso,steamed milk\nToppings: Caramel crunch, light foam',
            price: '₱95',
          ),
          CoffeeItem(
            imagePath: 'assets/img/6.png',
            name: 'Matcha',
            description: 'Green tea latte para sa mga independent\nna di kailangan ng ka-date.\nIngredients: Matcha powder, oat milk, espresso shot (optional)\nToppings: Cream foam, crushed graham',
            price: '₱99',
          ),
          CoffeeItem(
            imagePath: 'assets/img/8.png',
            name: 'Choco',
            description: 'Secret Love? Eto na lang muna.\nIngredients: Choco hazelnut sauce, espresso, milk\nToppings: Nutty choco bits, choco flakes',
            price: '₱89',
          ),
          CoffeeItem(
            imagePath: 'assets/img/7.png',
            name: 'Mocha',
            description: 'Sweet mocha blend. Kasi mukhang nahuhulog ka na naman.\nIngredients: Dark chocolate\nsyrup, espresso, steamed milk\nToppings: Choco drizzle, heart sprinkles',
            price: '₱95',
          ),
          CoffeeItem(
            imagePath: 'assets/img/9.png',
            name: 'Cinnamon Roll Latte',
            description: 'Cinnamon Latte na may extra init ng alaala.\nIngredients: Cinnamon powder,\nsteamed milk, espresso\nToppings: Whipped cream, cinnamon dust',
            price: '₱89',
          ),
          CoffeeItem(
            imagePath: 'assets/img/10.png',
            name: 'Dark Espresso',
            description: 'Flirty espresso shot na ‘di mo malilimutan.\nIngredients: Bold espresso, sugar shot, foamed milk\nToppings: Kilig dust (cocoa), mini heart marshmallow',
            price: '₱85',
          ),
          CoffeeItem(
            imagePath: 'assets/img/4.png',
            name: 'Vanilla Latte',
            description: 'Vanilla latte na pang-forever talaga ang sarap.\nPerfect for finding your greatest love\nIngredients: Vanilla syrup, espresso, milk\nToppings: Cream swirl, gold dust sugar',
            price: '₱89',
          ),
        ],
      ),
    );
  }
}

class CoffeeItem extends StatelessWidget {
  final String imagePath;
  final String name;
  final String description;
  final String price;

  const CoffeeItem({
    super.key,
    required this.imagePath,
    required this.name,
    required this.description,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.brown[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.brown.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Natural height image
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              imagePath,
              fit: BoxFit.cover,
              width: double.infinity,
              // Let it define its own height naturally
            ),
          ),
          const SizedBox(height: 12),

          // Row with left and right sides
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // LEFT SIDE: Name + Description
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black87,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),

                // RIGHT SIDE: Price + Add Button
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 38,
                        fontWeight: FontWeight.bold,
                        color: Colors.brown,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton.icon(
                      onPressed: () {
                        print('Added $name');
                      },
                      icon: const Icon(Icons.add, size: 16),
                      label: const Text('Add'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.brown,
                        foregroundColor: Colors.white,
                        elevation: 2,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        textStyle: const TextStyle(fontSize: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
